﻿namespace Observer
{
    public interface Display
    {
        public void Display();
    }
}